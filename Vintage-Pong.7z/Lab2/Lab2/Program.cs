﻿//********************************************************************************
//Sibat Hassan Lab #2
//********************************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using GDIDrawer;

namespace Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            CDrawer pong = new CDrawer();                                               //create drawing window variable
            int xBall = 0;                                                              //starting X position of ball
            int yBall = 0;                                                              //starting Y position of ball
            int xVel = 1;                                                               //X velocity of ball
            int yVel = 1;                                                               //Y velocity of ball
            bool xBallDecrease = false;                                                 //move ball left or right
            bool yBallDecrease = false;                                                 //move ball up or down
            Point mousePosition;                                                        //mouse position
            int yMouseOld = 0;                                                          //mouse old Y position
            int yMouseNew = 0;                                                          //mouse new Y position
            int yPaddleStart = 0;                                                       //paddle start value
            int yPaddleEnd = 0;                                                         //paddle end value
            int score = 0;                                                              //count score
            bool gameOver = false;                                                      //end game if ball leaves the left edge
            bool buttonClicked = false;                                                 //check if button is clicked
            bool closeGame = false;                                                     //close game window
            Random rand = new Random();                                                 //random starting position of ball

            //Set GDIDrawer window scale to 5.
            pong.Scale = 5;                                                             //set pixel scale to 5

            pong.ContinuousUpdate = false;                                              //set continuous update to false

            //Use nested for loops to draw table edges around three sides of window as background scaled pixels.
            for (int i = 0; i < 120; i++)
            {
                for (int j = 0; j < 160; j++)
                {
                    if (i == 0 || i == 119)
                    {
                        pong.SetBBScaledPixel(j, i, Color.Aqua);                        //Draw top and bottom table edges
                    }
                    else
                    {
                        if (j == 159)
                        {
                            pong.SetBBScaledPixel(j, i, Color.Aqua);                    //Draw right table edge
                        }
                    }
                }
            }

            //Render three edges on GDIDrawer window.
            pong.Render();                                                              //render frame with three edges

            //Run the game again if user left clicks "Play Again" button or close game if user left clicks "Quit" button.
            while (closeGame == false)
            {
                //Reset variables for every new game.
                xBall = rand.Next(5, 150);                                              //use random starting X value for ball
                yBall = rand.Next(5, 110);                                              //use random starting Y value for ball
                yPaddleStart = 55;                                                      //fixed starting position of paddle
                yPaddleEnd = 65;                                                        //fixed ending position of paddle
                xBallDecrease = false;                                                  //move ball towards the right
                yBallDecrease = false;                                                  //move ball towards the bottom
                score = 0;                                                              //reset score
                buttonClicked = false;                                                  //wait for button click

                //Clear screen before every new game.
                pong.Clear();                                                           //clear game screen

                //Add "Start" button.
                pong.AddRectangle(76, 50, 16, 8, Color.Black, 1, Color.Green);          //add rectangle for "Start" button
                pong.AddText("Start", 10, 74, 44, 20, 20, Color.Green);                 //add text for "Start" button

                //Render screen for new game.
                pong.Render();                                                          //render new game screen

                //Wait before new game until user left clicks the "Start" button.
                while (buttonClicked == false)
                {
                    //Read user mouse left click and get location of click.
                    pong.GetLastMouseLeftClickScaled(out mousePosition);                //get mouse left click position

                    //Check if user left clicked the "Start" button.
                    if (mousePosition.X >= 76 && mousePosition.X <= 92 && mousePosition.Y >= 50 && mousePosition.Y < 58)
                    {
                        buttonClicked = true;                                           //end loop
                    }
                }

                buttonClicked = false;                                                  //reset for next button check

                //Get mouse position before starting animation.
                pong.GetLastMousePosition(out mousePosition);                           //get mouse position
                yMouseOld = mousePosition.Y;                                            //set old mouse position

                //Draw and animate both ball as a rectangle with a size of 2 and paddle with thickness of 10 pixels.
                while (gameOver == false)
                {
                    //Draw paddle with thickness of 10 pixels.
                    pong.AddLine(1, yPaddleStart, 1, yPaddleEnd, Color.Red, 10);        //add paddle

                    //Get mouse position and set it to new mouse position.
                    pong.GetLastMousePosition(out mousePosition);                       //get mouse position
                    yMouseNew = mousePosition.Y;                                        //set new mouse position

                    //If mouse moved downwards then increment the paddle position. Otherwise,
                    //if mouse moved upwards then decrement paddle position.
                    //Also check if the paddle is hitting the top or bottom edge and stop the increment or decrement of paddle position.
                    if (yMouseNew > yMouseOld && yPaddleEnd < 118)
                    {
                        yPaddleStart++;                                                 //increment paddle start position
                        yPaddleEnd++;                                                   //increment paddle end position
                    }
                    else
                    {
                        if (yMouseNew < yMouseOld && yPaddleStart > 2)
                        {
                            yPaddleStart--;                                             //decrement paddle start position
                            yPaddleEnd--;                                               //decrement paddle end position
                        }
                    }

                    //Set old mouse position equal to new mouse position.
                    yMouseOld = yMouseNew;

                    //Draw the Ball.
                    pong.AddCenteredRectangle(xBall, yBall, 2, 2, Color.Green);         //add ball

                    //Render the ball and paddle to screen.
                    pong.Render();                                                      //render frame to GDIDrawer window

                    //Slow the movement of ball.
                    System.Threading.Thread.Sleep(20);                                  //wait before every frame rendering

                    //If ball hits the bottom edge then set the ball Y decrement to true. Otherwise, 
                    //if the ball hits the top edge then set the ball Y decrement to false. 
                    if (yBall == 118)
                    {
                        yBallDecrease = true;                                           //ball hits the bottom edge
                    }
                    else
                    {
                        if (yBall == 2)
                        {
                            yBallDecrease = false;                                      //ball hits the top edge
                        }
                    }

                    //If ball hits the right edge then set the ball X decrement to true. Otherwise, 
                    //if the ball hits the left edge then set the ball X decrement to false. 
                    //Also check if ball is hitting the paddle before setting the ball X decrement to false.
                    //Increase score if ball hits the paddle otherwise wait for few seconds before ending game.
                    if (xBall == 158)
                    {
                        xBallDecrease = true;                                           //ball hits the right edge
                    }
                    else
                    {
                        if (xBall == 3)
                        {
                            //Add collision detection of ball with the paddle.
                            //If ball hits paddle then increase score.
                            if (yBall >= yPaddleStart && yBall <= yPaddleEnd)
                            {
                                xBallDecrease = false;                                  //ball hits the left edge
                                score++;                                                //increase score
                            }
                        }
                        else
                        {
                            //If ball goes accross the left edge then end game after a few seconds.
                            if (xBall < -50)
                            {
                                gameOver = true;                                        //end game
                            }
                        }
                    }

                    //If ball is moving towards the right then add X value otherwise subtract X value.
                    if (xBallDecrease == false)
                    {
                        xBall += xVel;                                                  //move towards right
                    }
                    else
                    {
                        xBall -= xVel;                                                  //move towards left
                    }

                    //If ball is moving towards the bottom then add Y value otherwise subtract Y value.
                    if (yBallDecrease == false)
                    {
                        yBall += yVel;                                                  //move towards bottom
                    }
                    else
                    {
                        yBall -= yVel;                                                  //move towards top
                    }

                    //Clear GDIDrawer window before printing next animation frame.
                    pong.Clear();                                                       //clear GDIDrawer window before every frame rendering
                }

                //Display final score.
                pong.AddText("Final Score: " + score, 20, Color.Gray);                  //add score text box

                //Render score window.
                pong.Render();                                                          //render frame with final score

                //Wait before displaying "Play Again" and "Quit" buttons.
                System.Threading.Thread.Sleep(1000);                                    //delay rendering of "Play Again" and "Quit" buttons

                //Add "Play Again" buttons.
                pong.AddRectangle(101, 106, 16, 8, Color.Black, 1, Color.Green);        //add rectangle for "Play Again" button
                pong.AddText("Play Again", 10, 99, 100, 20, 20, Color.Green);           //add text for "Play Again" button

                //Add "Quit" buttons.
                pong.AddRectangle(131, 106, 16, 8, Color.Black, 1, Color.Gray);         //add rectangle for "Quit" button
                pong.AddText("Quit", 10, 129, 100, 20, 20, Color.Gray);                 //add text for "Quit" button

                //Render "Play Again" and "Quit" buttons.
                pong.Render();                                                          //render new frame for "Play Again" and "Quit" buttons

                //Wait until user left clicks "Play Again" or "Quit" button.
                while (buttonClicked == false)
                {
                    //Read user mouse left click and get location of click.
                    pong.GetLastMouseLeftClickScaled(out mousePosition);                //get mouse left click position

                    //Check if user left clicked the "Play Again" button.
                    if (mousePosition.X >= 101 && mousePosition.X <= 117 && mousePosition.Y >= 106 && mousePosition.Y < 114)
                    {
                        buttonClicked = true;                                           //end loop
                        gameOver = false;                                               //run game again
                    }

                    //Check if user left clicked the "Quit" button.
                    if (mousePosition.X >= 131 && mousePosition.X < 147 && mousePosition.Y >= 106 && mousePosition.Y < 114)
                    {
                        buttonClicked = true;                                           //end loop
                        closeGame = true;                                               //close game window
                    }
                }
            }
        }
    }
}